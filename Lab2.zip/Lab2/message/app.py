from flask import Flask, jsonify
import random, json

app = Flask(__name__)

with open('messages.json') as file:
    messages = json.load(file)

@app.route("/message", methods=["GET"])
def message():
    return jsonify({"message": random.choice(messages)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
